    <footer>
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <p class="copyright">&copy; <?php echo date("Y"); ?> All rights reserved Rixy Skin Care. Developed by <a target="_blank" href="#dyseaTech">DyseaTech</a></p>
                </div>
            </div>
        </div>
    </footer>


    
    <!-- search-modal -->
    <div class="modal fade" id="search-modal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <img src="images/search-popup-logo.png" alt="search-popup-logo">
                <form action="#" class="form-inline">
                    <input type="text" name="search" placeholder="Search here...">
                    <button><i class="fa fa-search"></i></button>
                </form>
                <div class="quick-search">
                    <h6 class="color-ff pos-relative ptb-30">Quick search</h6>
                    
                </div>
            </div>
        </div>
    </div>


     <!-- ======================================= 
        ==Start scroll top==  
    =======================================-->
    <div class="scroll-top not-visible"><i class="fa fa-angle-up"></i></div>
    <!-- =======================================
        ==End scroll top==  
    =======================================-->