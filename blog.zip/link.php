<div class="post-categories single-widget bg-darks" >
    <h5 class="widget-title fw-500 pos-relative">Dashboard</h5>
    <ul>
        <li class="<?php echo findBaseNamex('dashboard'); ?>"><a href="dashboard">My Products</a></li>
        <li class="<?php echo findBaseNamex('categories'); ?>"><a href="categories">Categories</a></li>
        <li class="<?php echo findBaseNamex('sub-categories'); ?>"><a href="sub-categories">Sub Categories</a></li>
        <li class="<?php echo findBaseNamex('settings'); ?>"><a href="settings">Settings</a></li>
        <li class="<?php echo findBaseNamex('blog'); ?>"><a href="blog">Blog</a></li>
        <!-- <li class="<?php //echo findBaseNamex('all-request'); ?>"><a href="all-request">All Request</a></li> -->
        <li class="<?php echo findBaseNamex('change-password'); ?>"><a href="change-password">Change Password</a></li>
        <li><a href="logout">Logout</a></li>
    </ul>
</div>